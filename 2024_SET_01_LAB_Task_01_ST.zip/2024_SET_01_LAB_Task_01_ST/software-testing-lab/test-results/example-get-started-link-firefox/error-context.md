# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: example.spec.js >> get started link
- Location: e2e\example.spec.js:11:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.goto: Test timeout of 30000ms exceeded.
Call log:
  - navigating to "https://playwright.dev/", waiting until "load"

```

# Page snapshot

```yaml
- generic [ref=e2]:
  - region "Skip to main content":
    - link "Skip to main content" [ref=e3] [cursor=pointer]:
      - /url: "#__docusaurus_skipToContent_fallback"
  - navigation "Main" [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]:
        - link "Playwright logo Playwright" [ref=e7] [cursor=pointer]:
          - /url: /
          - img "Playwright logo" [ref=e9]
          - generic [ref=e10]: Playwright
        - link "Docs" [ref=e11] [cursor=pointer]:
          - /url: /docs/intro
        - link "MCP" [ref=e12] [cursor=pointer]:
          - /url: /mcp/introduction
        - link "CLI" [ref=e13] [cursor=pointer]:
          - /url: /agent-cli/introduction
        - link "API" [ref=e14] [cursor=pointer]:
          - /url: /docs/api/class-playwright
        - button "Node.js" [ref=e16] [cursor=pointer]
      - generic [ref=e17]:
        - link "GitHub repository" [ref=e18] [cursor=pointer]:
          - /url: https://github.com/microsoft/playwright
        - link "Discord server" [ref=e19] [cursor=pointer]:
          - /url: https://aka.ms/playwright/discord
        - button "Switch between dark and light mode (currently system mode)" [disabled] [ref=e21]
        - button "Search (Meta+k)" [ref=e25] [cursor=pointer]:
          - generic [ref=e26]: Search
  - generic [ref=e31]:
    - banner [ref=e32]:
      - generic [ref=e33]:
        - heading "Playwright enables reliable web automation for testing, scripting, and AI agents." [level=1] [ref=e34]
        - paragraph [ref=e35]:
          - text: One API to drive Chromium, Firefox, and WebKit — in your tests, your scripts, and your agent workflows. Available for
          - link "TypeScript" [ref=e36] [cursor=pointer]:
            - /url: https://playwright.dev/docs/intro
          - text: ","
          - link "Python" [ref=e37] [cursor=pointer]:
            - /url: https://playwright.dev/python/docs/intro
          - text: ","
          - link ".NET" [ref=e38] [cursor=pointer]:
            - /url: https://playwright.dev/dotnet/docs/intro
          - text: ", and"
          - link "Java" [ref=e39] [cursor=pointer]:
            - /url: https://playwright.dev/java/docs/intro
          - text: .
        - generic [ref=e40]:
          - link "Get started" [ref=e41] [cursor=pointer]:
            - /url: /docs/intro
          - generic [ref=e42]:
            - link "Star microsoft/playwright on GitHub" [ref=e43] [cursor=pointer]:
              - /url: https://github.com/microsoft/playwright
              - text: Star
            - link "97k+ stargazers on GitHub" [ref=e45] [cursor=pointer]:
              - /url: https://github.com/microsoft/playwright/stargazers
              - text: 97k+
    - main [ref=e46]:
      - generic [ref=e49]:
        - generic [ref=e50]:
          - heading "Playwright Test" [level=3] [ref=e51]
          - paragraph [ref=e52]: Full-featured test runner with auto-waiting, assertions, tracing, and parallelism across Chromium, Firefox, and WebKit.
          - code [ref=e53]: npm init playwright@latest
          - link "Testing documentation" [ref=e55] [cursor=pointer]:
            - /url: /docs/intro
        - generic [ref=e56]:
          - heading "Playwright CLI" [level=3] [ref=e57]
          - paragraph [ref=e58]: Token-efficient browser automation for coding agents like Claude Code and GitHub Copilot. Skill-based workflows without large context overhead.
          - code [ref=e59]: npm i -g @playwright/cli@latest
          - link "CLI documentation" [ref=e61] [cursor=pointer]:
            - /url: /docs/getting-started-cli
        - generic [ref=e62]:
          - heading "Playwright MCP" [level=3] [ref=e63]
          - paragraph [ref=e64]: Model Context Protocol server that gives AI agents full browser control through structured accessibility snapshots.
          - code [ref=e65]: npx @playwright/mcp@latest
          - link "MCP documentation" [ref=e67] [cursor=pointer]:
            - /url: /docs/getting-started-mcp
      - generic [ref=e69]:
        - heading "Built for testing" [level=2] [ref=e70]
        - generic [ref=e72]:
          - generic [ref=e73]:
            - heading "Auto-wait and web-first assertions" [level=4] [ref=e74]
            - paragraph [ref=e75]: Playwright waits for elements to be actionable before performing actions. Assertions automatically retry until conditions are met. No artificial timeouts, no flaky tests.
            - heading "Test isolation" [level=4] [ref=e76]
            - paragraph [ref=e77]: Each test gets a fresh browser context — equivalent to a brand new browser profile. Full isolation with near-zero overhead. Save authentication state once and reuse it across tests.
          - generic [ref=e78]:
            - heading "Resilient locators" [level=4] [ref=e79]
            - paragraph [ref=e80]:
              - text: "Find elements with selectors that mirror how users see the page:"
              - code [ref=e81]: getByRole
              - text: ","
              - code [ref=e82]: getByLabel
              - text: ","
              - code [ref=e83]: getByPlaceholder
              - text: ","
              - code [ref=e84]: getByTestId
              - text: . No brittle CSS paths.
            - heading "Parallelism and sharding" [level=4] [ref=e85]
            - paragraph [ref=e86]: Tests run in parallel by default across all configured browsers. Shard across multiple machines for faster CI. Full cross-browser coverage on every commit.
      - generic [ref=e88]:
        - heading "Built for AI agents" [level=2] [ref=e89]
        - generic [ref=e91]:
          - generic [ref=e92]:
            - heading "Accessibility snapshots, not screenshots" [level=4] [ref=e93]
            - paragraph [ref=e94]: Agents interact with pages through structured accessibility trees — element roles, names, and refs. Deterministic and unambiguous, no vision models required.
            - heading "MCP server" [level=4] [ref=e95]
            - paragraph [ref=e96]:
              - text: Drop-in
              - link "Model Context Protocol" [ref=e97] [cursor=pointer]:
                - /url: https://modelcontextprotocol.io
              - text: server for VS Code, Cursor, Claude Desktop, Windsurf, and any MCP client. Full browser control through standard tool calls.
          - generic [ref=e98]:
            - heading "CLI for coding agents" [level=4] [ref=e99]
            - paragraph [ref=e100]: Token-efficient command-line interface with installable skills. Purpose-built for Claude Code, GitHub Copilot, and similar coding agents that need to balance browser automation with large codebases.
            - heading "Session monitoring" [level=4] [ref=e101]
            - paragraph [ref=e102]: Visual dashboard with live screencast previews of all running browser sessions. Click any session to zoom in and take control.
      - generic [ref=e104]:
        - heading "Powerful tooling" [level=2] [ref=e105]
        - generic [ref=e107]:
          - generic [ref=e108]:
            - heading [level=4] [ref=e109]:
              - link "Test generator" [ref=e110] [cursor=pointer]:
                - /url: docs/codegen
            - paragraph [ref=e111]: Record your actions in the browser and Playwright writes the test code. Generate assertions from the recording toolbar. Pick locators by clicking on elements.
          - generic [ref=e112]:
            - heading [level=4] [ref=e113]:
              - link "Trace Viewer" [ref=e114] [cursor=pointer]:
                - /url: docs/trace-viewer-intro
            - paragraph [ref=e115]: Full timeline of test execution with DOM snapshots, network requests, console logs, and screenshots at every step. Investigate failures without re-running.
          - generic [ref=e116]:
            - heading [level=4] [ref=e117]:
              - link "VS Code extension" [ref=e118] [cursor=pointer]:
                - /url: docs/getting-started-vscode
            - paragraph [ref=e119]: Run, debug, and generate tests directly in the editor. Set breakpoints, live-inspect locators in the browser, and view full execution traces in the sidebar.
      - generic [ref=e121]:
        - img "Chromium, Firefox, WebKit" [ref=e122]
        - paragraph [ref=e123]:
          - text: Any browser. Any platform. Chromium, Firefox, and WebKit on Linux, macOS, and Windows. Headless and headed. Also available for
          - link "Python" [ref=e124] [cursor=pointer]:
            - /url: https://playwright.dev/python/docs/intro
          - text: ","
          - link ".NET" [ref=e125] [cursor=pointer]:
            - /url: https://playwright.dev/dotnet/docs/intro
          - text: ", and"
          - link "Java" [ref=e126] [cursor=pointer]:
            - /url: https://playwright.dev/java/docs/intro
          - text: .
      - generic [ref=e130]:
        - heading "Chosen by companies and open source projects" [level=2] [ref=e131]
        - list [ref=e132]:
          - listitem [ref=e133]:
            - link [ref=e134] [cursor=pointer]:
              - /url: https://code.visualstudio.com
              - img "VS Code" [ref=e135]
          - listitem [ref=e136]:
            - link [ref=e137] [cursor=pointer]:
              - /url: https://bing.com
              - img "Bing" [ref=e138]
          - listitem [ref=e139]:
            - link [ref=e140] [cursor=pointer]:
              - /url: https://outlook.com
              - img "Outlook" [ref=e141]
          - listitem [ref=e142]:
            - link [ref=e143] [cursor=pointer]:
              - /url: https://www.hotstar.com/
              - img "Disney+ Hotstar" [ref=e144]
          - listitem [ref=e145]:
            - link [ref=e146] [cursor=pointer]:
              - /url: https://github.com/mui-org/material-ui
              - img "Material UI" [ref=e147]
          - listitem [ref=e148]:
            - link [ref=e149] [cursor=pointer]:
              - /url: https://github.com/ing-bank/lion
              - img "ING" [ref=e150]
          - listitem [ref=e151]:
            - link [ref=e152] [cursor=pointer]:
              - /url: https://github.com/adobe/spectrum-web-components
              - img "Adobe" [ref=e153]
          - listitem [ref=e154]:
            - link [ref=e155] [cursor=pointer]:
              - /url: https://github.com/react-navigation/react-navigation
              - img "React Navigation" [ref=e156]
          - listitem [ref=e157]:
            - link [ref=e158] [cursor=pointer]:
              - /url: https://accessibilityinsights.io/
              - img "Accessibility Insights" [ref=e159]
  - contentinfo [ref=e160]:
    - generic [ref=e161]:
      - generic [ref=e162]:
        - generic [ref=e163]:
          - generic [ref=e164]: Learn
          - list [ref=e165]:
            - listitem [ref=e166]:
              - link "Getting started" [ref=e167] [cursor=pointer]:
                - /url: /docs/intro
            - listitem [ref=e168]:
              - link [ref=e169] [cursor=pointer]:
                - /url: https://learn.microsoft.com/en-us/training/modules/build-with-playwright/
                - text: Playwright Training
                - img "(opens in new tab)" [ref=e170]
            - listitem [ref=e172]:
              - link "Learn Videos" [ref=e173] [cursor=pointer]:
                - /url: /community/learn-videos
            - listitem [ref=e174]:
              - link "Feature Videos" [ref=e175] [cursor=pointer]:
                - /url: /community/feature-videos
        - generic [ref=e176]:
          - generic [ref=e177]: Community
          - list [ref=e178]:
            - listitem [ref=e179]:
              - link [ref=e180] [cursor=pointer]:
                - /url: https://stackoverflow.com/questions/tagged/playwright
                - text: Stack Overflow
                - img "(opens in new tab)" [ref=e181]
            - listitem [ref=e183]:
              - link [ref=e184] [cursor=pointer]:
                - /url: https://aka.ms/playwright/discord
                - text: Discord
                - img "(opens in new tab)" [ref=e185]
            - listitem [ref=e187]:
              - link [ref=e188] [cursor=pointer]:
                - /url: https://x.com/playwrightweb
                - text: X
                - img "(opens in new tab)" [ref=e189]
            - listitem [ref=e191]:
              - link [ref=e192] [cursor=pointer]:
                - /url: https://www.linkedin.com/company/playwrightweb
                - text: LinkedIn
                - img "(opens in new tab)" [ref=e193]
        - generic [ref=e195]:
          - generic [ref=e196]: More
          - list [ref=e197]:
            - listitem [ref=e198]:
              - link [ref=e199] [cursor=pointer]:
                - /url: https://github.com/microsoft/playwright
                - text: GitHub
                - img "(opens in new tab)" [ref=e200]
            - listitem [ref=e202]:
              - link [ref=e203] [cursor=pointer]:
                - /url: https://www.youtube.com/channel/UC46Zj8pDH5tDosqm1gd7WTg
                - text: YouTube
                - img "(opens in new tab)" [ref=e204]
            - listitem [ref=e206]:
              - link [ref=e207] [cursor=pointer]:
                - /url: https://dev.to/playwright
                - text: Blog
                - img "(opens in new tab)" [ref=e208]
            - listitem [ref=e210]:
              - link "Ambassadors" [ref=e211] [cursor=pointer]:
                - /url: /community/ambassadors
            - listitem [ref=e212]:
              - link [ref=e213] [cursor=pointer]:
                - /url: https://go.microsoft.com/fwlink/?LinkId=521839
                - text: Microsoft Privacy Statement
                - img "(opens in new tab)" [ref=e214]
      - generic [ref=e216]: Copyright © 2026 Microsoft
```

# Test source

```ts
  1  | // @ts-check
  2  | import { test, expect } from '@playwright/test';
  3  | 
  4  | test('has title', async ({ page }) => {
  5  |   await page.goto('https://playwright.dev/');
  6  | 
  7  |   // Expect a title "to contain" a substring.
  8  |   await expect(page).toHaveTitle(/Playwright/);
  9  | });
  10 | 
  11 | test('get started link', async ({ page }) => {
> 12 |   await page.goto('https://playwright.dev/');
     |              ^ Error: page.goto: Test timeout of 30000ms exceeded.
  13 | 
  14 |   // Click the get started link.
  15 |   await page.getByRole('link', { name: 'Get started' }).click();
  16 | 
  17 |   // Expects page to have a heading with the name of Installation.
  18 |   await expect(page.getByRole('heading', { name: 'Installation' })).toBeVisible();
  19 | });
  20 | 
```